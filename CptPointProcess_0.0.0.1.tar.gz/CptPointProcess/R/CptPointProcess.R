#' CptPointProcess
#'
#' Change-point detection in the intensity of a Poisson Process or in both the intensity and the mark parameter of a Marked Poisson Process
#'
#'@param ProcessData a data.frame with n rows and 1 or 2 columns containing the n events normalized between 0 and 1 (named times) and the n associated marks if a Marked Poisson Process is considered (named marks).
#'@param marked a logical value indicating if a Marked Poisson Process is considered. Default is FALSE, meaning that is a Poisson process. If it is TRUE, ProcessData must contain the vector of the marks.
#'@param Kmax the maximal number of segments (will be lower than n). Default is 10.
#'@param selection a logical value indicating if the selection of the number of segments K is performed. Default is TRUE. If it is FALSE, K is fixed to \code{Kmax}.
#'@param parms.CV a list of two parameters used for the cross-validation: f is the sampling probability for the learn sample and B is the number of resampling. Default is f=4/5 and B=200.
#'
#' @return A list containing
#' \itemize{
#' \item \code{K.est} the selected number of segments otained from the cross validation if \code{selection==TRUE} and \code{Kmax} if \code{selection==FALSE}.
#'\item \code{SegK} the obtained segmentation with \code{K.est} segments. It is a data.frame containing for each row, i.e. for each segment
#'\itemize{
#'\item \code{begin} the beginning,
#'\item \code{end} the end,
#'\item \code{code.end} a code indicating if the change-point is located just before \code{end}, i.e. just before an event $T^-$ (code.end ="-") or exactly \code{end}, i.e. at exactly an event $T$ (code.end="."),
#'\item \code{Dt} the segment length,
#'\item \code{DN} the number of events that occurs in the segment,
#'\item \code{lambda} the estimated intensity,
#'\item \code{DM} the sum of the marks that occur in the segment if \code{marked==TRUE},
#'\item \code{rho} the estimated marked parameter if \code{marked==TRUE}.
#'}
#' \item \code{Contrast} the contrast function for K=1,...,\code{K.est}. If \code{k.select==TRUE}, this is the contrast obtained from the cross-validation and used for the selection of K. If \code{k.select==FALSE}, this is the contrast of the best segmentation into K=1,...,\code{K.est} segments (the Poisson-Gamma (PG) contrast if \code{marked==FALSE} or the Marked-Poisson-Gamma-Exponential-Gamma (MPGEG) contrast if \code{marked==TRUE}).
#' }
#'
#' @details
#' In the Marked Poisson Process, the marks are independent random variables following an exponential distribution with parameter rho that is assumed to be also affected by the changes.
#'
#' If \code{selection==FALSE}, the used contrast is the Poisson-Gamma (PG) contrast with hyperparameters a=1 and b=1/n if \code{marked==FALSE} and the Marked-Poisson-Gamma-Exponential-Gamma (MPGEG) contrast with hyperparameters al=1, bl=1/n, ar=2.01 and br= mean(marks) (ar-1) if \code{marked==TRUE}.
#'
#' If \code{selection==TRUE}, a cross-validation is used to select the number of segments: a learning process is sampled with probability f from the poisson process and the remaining events forms the testing sample. The learn sample is segmented using the PG (or the MPGEG) contrast and posterior mean of the intensity parameter (and rho parameter) is calculated. Then the Poisson (or the Marked Poisson) contrast with these estimated parameters is calculated on the test sample.
#'
#' @examples
#' data(ProcessData)
#' marked <- TRUE
#' selection <- FALSE
#' Kmax <- 6
#' Res.Seg=CptPointProcess(ProcessData,marked=marked,Kmax=Kmax,selection=selection)
#' @export


CptPointProcess <- function(ProcessData,marked=FALSE, Kmax=10, selection=TRUE,parms.CV=list(f=4/5,B=200)){

  # Number of events
  n <- nrow(ProcessData)
  p <-ncol(ProcessData)

  ###### Tests
  ## X
  if (is.data.frame(ProcessData) == FALSE){
    stop('ProcessData must be a data.frame')
  }

  if (ProcessData$times[1]==0 | ProcessData$times[n]==1){
    stop('The events times must be strickly lower than 1 and strickly greater than 0')
  }

  ## Kmax
  if (Kmax==1 || Kmax==n){
    stop('Kmax must be lower than n and greater than 1')
  }

  ## MPP
  if ((marked==TRUE) & !("marks" %in% colnames(ProcessData))){
    stop('A Marked Poisson Process is considered but the marks is not available')
  }



  # Tests
  if (selection==FALSE){

    if (marked==FALSE){
      times <- ProcessData$times
      marks <- NA
      breaks <-  PotentialBreaks(times,marks,marked)
      parms <- list(a = 1, b = 1/n, lga = 0)
      cost <- CostMatrix(breaks = breaks, ContrastSeg = ContrastSeg.PG.ab, parms=parms)
      resDP <- DynProg(costMat = cost,Kmax = Kmax)

      SegK <- BestSeg.K(breaks=breaks, resDP=resDP, K=Kmax,parms=parms)
      Contrast <- resDP$J.est
      K.est <- Kmax


    }

    if (marked==TRUE){
      times <- ProcessData$times
      marks <- ProcessData$marks

      breaks <-  PotentialBreaks(times,marks,marked)
      am = 2.01
      bm =  mean(marks)*(am-1)
      lgam = lgamma(am)
      parms <- list(a = 1, b = 1/n, lga = 0,am=am,bm=bm,lgam=lgam)
      cost <- CostMatrix(breaks = breaks, ContrastSeg = ContrastSeg.PG.ab, parms=parms)
      resDP <- DynProg(costMat = cost,Kmax = Kmax)

      SegK <- BestSeg.K(breaks=breaks, resDP=resDP, K=Kmax,parms=parms)
      Contrast <- resDP$J.est
      K.est <- Kmax

    }
  }

  if (selection==TRUE){

    if (marked==FALSE){
      times <- ProcessData$times
      marks <- NA

      ## CV
      cv <- LoopCostCV(times=times,marks=marks , parms.CV=parms.CV, LearnStep=LearnStep,TestStep=TestStep,Kmax=Kmax,marked=marked)

      Contrast <- colMeans(cv)
      K.est <- which.min(Contrast)
      ## Optimal solution with K.est segments
      breaks <-  PotentialBreaks(times,marks,marked)
      parms <- list(a = 1, b = 1/n, lga = 0)
      cost <- CostMatrix(breaks = breaks, ContrastSeg = ContrastSeg.PG.ab, parms=parms)
      resDP <- DynProg(costMat = cost,Kmax = K.est)
      SegK <- BestSeg.K(breaks=breaks, resDP=resDP, K=K.est,parms=parms)
    }

    if (marked==TRUE){
      times <- ProcessData$times
      marks <- ProcessData$marks
      ## CV
      cv <- LoopCostCV(times=times,marks=marks , parms.CV=parms.CV, LearnStep=LearnStep,TestStep=TestStep,Kmax=Kmax,marked=marked)
      Contrast <- colMeans(cv)
      K.est <- which.min(Contrast)
      ## Optimal solution with K.est segments
      breaks <-  PotentialBreaks(times=times,marks=marks,marked=marked)
      am = 2.01
      bm =  mean(marks)*(am-1)
      lgam = lgamma(am)
      parms <- list(a = 1, b = 1/n, lga = 0,am=am,bm=bm,lgam=lgam)
      cost <- CostMatrix(breaks = breaks, ContrastSeg = ContrastSeg.PG.ab, parms=parms)
      resDP <- DynProg(costMat = cost,Kmax = Kmax)
      SegK <- BestSeg.K(breaks=breaks, resDP=resDP, K=K.est,parms=parms)
    }

  }

  return(list(K.est=K.est, SegK=SegK,Contrast=Contrast))

}

                      ############
                      ## Used Functions
                      ############

####################################
# Functions for segmentation
####################################

##### Breaks for DP
PotentialBreaks <- function(times, marks,marked){
  n <- length(times)
  if (marked==FALSE){
    time <- c(0, rep(times,each=2),1)
    code <- c("0", rep(c("-", "."), n), ".")
    N <- rep(c(0,1:n),each=2)
    return(list(time = time, code = code, N = N))
  }
  if(marked==TRUE){
    time <- c(0, rep(times,each=2),1)
    code <- c("0", rep(c("-", "."), n), ".")
    N <- rep(c(0,1:n),each=2)
    M.cum <- c(0,0, rep(cumsum(marks), each=2))
    return(list(time = time, code = code, N = N, M.cum=M.cum))
  }
}

##### CostMatrix
CostMatrix <-function(breaks, ContrastSeg, parms){
  nBreaks <- length(breaks$time)
  costMat <- matrix(Inf, nBreaks-1, nBreaks-1)

  # First line
  DNi <- breaks$N[2:nBreaks] - breaks$N[1] #breaks$N[1] =0
  Dti <- breaks$time[2:nBreaks] - breaks$time[1] #  breaks$time[1]=0

  if(length(breaks)==3){
    costMat[1, ] <- ContrastSeg(DN=DNi, Dt=Dti, DM=NA, parms=parms)
    for (i in 2:(nBreaks-1)){
      DNi <- breaks$N[(i+1):nBreaks]-breaks$N[i]
      Dti <- breaks$time[(i+1):nBreaks]-breaks$time[i]
      costMat[i, i:(nBreaks-1)] <- ContrastSeg(DN=DNi, Dt=Dti, DM = NA, parms=parms)
    }
  }


  if(length(breaks)>3){
    DMi= breaks$M.cum[2:nBreaks] - breaks$M.cum[1]
    costMat[1, ] <- ContrastSeg(DN=DNi, Dt=Dti, DM=DMi, parms=parms)
    for (i in 2:(nBreaks-1)){
      DNi <- breaks$N[(i+1):nBreaks]-breaks$N[i]
      Dti <- breaks$time[(i+1):nBreaks]-breaks$time[i]
      DMi <- breaks$M.cum[(i+1):nBreaks]-breaks$M.cum[i]
      costMat[i, i:(nBreaks-1)] <- ContrastSeg(DN=DNi, Dt=Dti, DM = DMi, parms=parms)
    }
  }
  return(costMat)
}

##### DP
DynProg <- function(costMat, Kmax){
  N <- dim(costMat)[1]
  if (Kmax > N){cat("Kmax ", Kmax, "is greater than N ", N, "\n")
    cat("Kmax is supposed to be equal to N :", N, "\n")
    Kmax <- 13
  }

  I <- matrix(Inf, Kmax, N)
  t <- matrix(0, Kmax, N)
  I[1, ] <- costMat[1, ]
  costMat <- t(costMat)


  if (Kmax>2){
    for (k in 2:(Kmax-1))
      for (L in k:N)
      {
        I[k, L]<-min(I[(k-1), 1:(L-1)]+costMat[L, 2:L])
        if(I[k, L]!=Inf)
          t[k-1, L]<-which.min(I[(k-1), 1:L-1]+costMat[L, 2:L])
      }
  }

  I[Kmax, N]<-min(I[Kmax-1, 1:(N-1)]+costMat[N, 2:N])
  if(I[Kmax, N]!=Inf)
    t[Kmax-1, N]<-which.min(I[(Kmax-1), 1:N-1]+costMat[N, 2:N])

  # *** Calculation of the change-points ***
  t.est<-matrix(0, Kmax, Kmax)
  diag(t.est)<-N
  for (K in 2:Kmax)
    for (k in seq(K-1, 1, by=-1))
    {
      if(t.est[K, k+1]!=0)
        t.est[K, k]<-t[k, t.est[K, k+1]]
    }
  list(J.est = I[, N], t.est = t.est)
}


##### Best segmentation
BestSeg.K <- function(breaks, resDP, K,parms){
  sol <- resDP$t.est[K, 1:K]
  tau <- breaks$time[sol+1]
  code <- breaks$code[sol+1]
  N <- breaks$N[sol+1]

  rupt <-  matrix(Inf, ncol=2, nrow=K)
  if(K > 1){
    rupt[, 2] <- tau
    rupt[, 1] <- c(0, tau[1:(K-1)])
  }else{rupt[1, ] <- c(0, 1)}

  seg <- data.frame(rupt,  code.end=code)
  colnames(seg) <- c("begin", "end","code.end")
  seg$Dt <- seg$end - seg$begin
  seg$DN <- diff(c(0, N))
  seg$lambda <- (seg$DN+parms$a)/(seg$Dt+parms$b)

  if(length(breaks)>3){
    seg$DM <- diff(c(0,breaks$M.cum[sol+1]))
    seg$rho <- (seg$DN+parms$am)/(seg$DM+parms$bm)
  }
  return(seg)
}


####################################
# Used Contrasts
####################################

##### Poisson-Gamma contrast
ContrastSeg.PG.ab <- function(DN, Dt, DM = NA, parms){

  if(sum(is.na(DM))>0){
    return(-parms$a*log(parms$b) + parms$lga - lgamma(parms$a + DN) + (parms$a + DN)*log(parms$b + Dt))
  }

  if(sum(is.na(DM))==0){
    return( (- parms$a*log(parms$b) + parms$lga - lgamma(parms$a + DN) + (parms$a + DN)*log(parms$b + Dt)) +(-parms$am*log(parms$bm) + parms$lgam - lgamma(parms$am + DN) + (parms$am + DN)*log(parms$bm + DM)))
  }
}

##### Poisson contrast with lambda (and rho)
ContrastSeg.P.lambda <- function(DN, Dt, DM=NA, parms){

  if(sum(is.na(DM))>0){
    return(- DN*log(parms$lambda) + Dt*parms$lambda)
  }

  if (sum(is.na(DM))==0){
    return(- DN*log(parms$lambda) +Dt*parms$lambda-DN * log(parms$rho)+ DM *parms$rho)
  }
}


####################################
# Functions for CV
####################################


##### Main function
LoopCostCV <- function(times,marks ,parms.CV, LearnStep, TestStep,Kmax,marked){

  f <- parms.CV$f
  B <- parms.CV$B
  fractionLearn <- f;  fractionTest <- 1 - fractionLearn;
  trainRatio <- fractionTest/fractionLearn
  n <- length(times)

  costCVmat <- matrix(NA, nrow=B, ncol=Kmax)

  if (marked==FALSE){
    costCVmat <- t(sapply(1:B, function(b){
      keep <- (stats::runif(n) < f)
      while((sum(keep)==n) | (sum(keep)<=1)){keep <- (stats::runif(n) < f)}
      timesLearn <- times[keep];timesTest <- times[!keep]
      marksLearn <- marks;  marksTest <- marks
      # Learn
      bestSegLearn <- LearnStep(timesLearn=timesLearn, marksLearn=marksLearn, Kmax=Kmax,marked=marked)
      # Test
      return(TestStep(timesTest= timesTest, marksTest=marksTest, bestSegLearn=bestSegLearn,marksLearn = marksLearn, trainRatio=trainRatio, Kmax=Kmax,marked=marked))
    }))
  }


  if (marked==TRUE){
    costCVmat <- t(sapply(1:B, function(b){
      keep <- (stats::runif(n) < f)
      while((sum(keep)==n) | (sum(keep)<=1)){keep <- (stats::runif(n) < f)}
      timesLearn <- times[keep];timesTest <- times[!keep]
      marksLearn <- marks[keep];marksTest <- marks[!keep]
      # Learn
      bestSegLearn <- LearnStep(timesLearn=timesLearn, marksLearn=marksLearn, Kmax=Kmax,marked=marked)
      # Test
      return(TestStep(timesTest= timesTest, marksTest=marksTest, bestSegLearn=bestSegLearn,marksLearn = marksLearn, trainRatio=trainRatio,Kmax=Kmax,marked=marked))
    }))
  }
  return(costCVmat)
}

##### Best segmentation for the Learn sample using PG contrast for K=1:Kmax
LearnStep <- function(timesLearn, marksLearn,Kmax, marked){

  if(marked==FALSE){
    breaksLearn <-  PotentialBreaks(timesLearn, marksLearn, marked)
    parmsLearn <- list(a = 1, b = 1/length(timesLearn), lga = 0)
  }

  if(marked==TRUE){
    breaksLearn <-  PotentialBreaks(timesLearn, marksLearn, marked)
    am = 2.01
    bm =  mean(marksLearn)*(am-1)
    lgam = lgamma(am)
    parmsLearn <- list(a = 1, b = 1/length(timesLearn), lga = 0,am=am,bm=bm,lgam=lgam)
  }

  costLearn <- CostMatrix(breaks = breaksLearn, ContrastSeg = ContrastSeg.PG.ab, parms=parmsLearn)
  resDPLearn <- DynProg(costMat = costLearn,Kmax = Kmax)
  return(sapply(1 : Kmax, function(k){BestSeg.K(breaks = breaksLearn, resDP = resDPLearn, K = k,parms=parmsLearn)}, simplify = FALSE))
}


##### Calculation of the Poisson contrast on the test sample using the posterior mean of lambda (and rho)

TestStep <- function(timesTest, marksTest, bestSegLearn, marksLearn, trainRatio,Kmax, marked){

  costCVvec <- rep(NA, Kmax)

  if(marked==FALSE){
    bestSegCV <- CountSegCV(bestSegLearn = bestSegLearn, timesTest = timesTest,marksTest = marksTest,marked=marked )
    costCVvec <- sapply(1 : Kmax, function(K){
      parmsP <- list(lambda= trainRatio * bestSegCV[[K]]$lambda)
      return(sum(ContrastSeg.P.lambda(DN=bestSegCV[[K]]$DNTest, Dt=bestSegCV[[K]]$Dt, DM= NA, parms=parmsP)))
    })
  }

  if(marked==TRUE){
    bestSegCV <- CountSegCV(bestSegLearn = bestSegLearn, timesTest = timesTest, marksTest = marksTest,marked=marked)
    costCVvec <- sapply(1 : Kmax, function(K){
      parmsP <- list(lambda= trainRatio * bestSegCV[[K]]$lambda, rho=bestSegCV[[K]]$rho)
      return(sum(ContrastSeg.P.lambda(DN=bestSegCV[[K]]$DNTest, Dt=bestSegCV[[K]]$Dt, DM= bestSegCV[[K]]$DMTest, parms=parmsP)))
    })
  }
  return(costCVvec)
}


##### Function that calculates the number of events (and the sum of marks) of the test sample on each segment of the estimated segmentation obtained from the learn sample
CountSegCV <- function(bestSegLearn, timesTest, marksTest,marked){

  res <- bestSegLearn
  for(K in 1:length(res)){
    res[[K]]$DNTest <- sapply(1 : K, function(k){
      sum((timesTest > res[[K]]$begin[k]) & (timesTest <= res[[K]]$end[k]))
    })
  }

  if(marked==TRUE){
    for(K in 1:length(res)){
      res[[K]]$DMTest <- sapply(1 : K, function(k){
        sum(marksTest[which((timesTest > res[[K]]$begin[k]) & (timesTest <= res[[K]]$end[k]))])
      })
    }
  }
  return(res)
}


