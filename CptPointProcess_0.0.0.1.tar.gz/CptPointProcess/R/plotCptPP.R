#' plotCptPP
#'
#' plot of the (Marked) Poisson process with the estimated segmentation
#'
#' @param ProcessData a data.frame with n rows and 1 or 2 columns containing the n events normalized between 0 and 1 (named times) and the n associated marks if a Marked Poisson Process is considered (named marks).
#' @param seg the estimated segmentation with K.est segments from the SegMPP function.
#' @param marked a logical value indicating if a Marked Poisson Process is considered.
#' @return This function returns a plot of the data and the estimated segmentation: one graph for a Poisson process and two graphs for the Marked Poisson Process (one for the Poisson Process on the left and one for the Marks on the right). The change-points are represented by vertical red dotted lines and the estimated intensity (and the estimated mean of the parameter of the marks) are represented with horizontal red lines.
#' @examples
#' data(ProcessData)
#' marked <- TRUE
#' selection <- FALSE
#' Kmax <- 6
#' Res.Seg=CptPointProcess(ProcessData,marked=marked,Kmax=Kmax,selection=selection)
#' plotCptPP(ProcessData,Res.Seg$SegK, marked)
#' @export

plotCptPP <- function(ProcessData,seg, marked=FALSE){

  xlab=''; ylab=''; main=''; col=2
  tStart=0; tEnd=1
  times <- ProcessData$times
  n <- length(times)

  if( marked==FALSE){
    # Times, N(t) and estimated CP
    graphics::par(new=FALSE)
    graphics::plot(0, xlim=c(tStart, tEnd), ylim=c(0, n), col=0, xlab=xlab, ylab=ylab, main=main)
    graphics::points(times, rep(0, n), pch=20,cex=0.8)
    graphics::lines(c(tStart, times, tEnd), c((0:n), n), type='s')
    if (nrow(seg)!=1){
      graphics::abline(v=seg$end[1:(length(seg$end)-1)], col=2, lty=2)
    }
    # Estimated lambda
    graphics:: par(new=TRUE)
    graphics::plot(0, xlim=c(tStart, tEnd), ylim=c(0, max(seg$lambda)), col=0,
         xlab=NA, ylab=NA, main=NA, axes=FALSE)
    for(k in 1:nrow(seg)){
      graphics::lines(c(seg$begin[k], seg$end[k]), seg$lambda[k]*c(1, 1), col=col, lwd=2)
    }
    graphics::axis(side=4, col=2, col.ticks=2, col.axis=2)
  }

  if(marked==TRUE){

    graphics::par(mfrow=c(1,2), mex=.7)
    ##### Poisson process
    # Times, N(t) and estimated CP
    graphics::par(new=FALSE)
    graphics::plot(0, xlim=c(tStart, tEnd), ylim=c(0, n), col=0, xlab=xlab, ylab=ylab, main=main)
    graphics::points(times, rep(0, n), pch=20,cex=0.8)
    graphics::lines(c(tStart, times, tEnd), c((0:n), n), type='s')
    if (nrow(seg)!=1){
      graphics::abline(v=seg$end[1:(length(seg$end)-1)], col=2, lty=2)
    }
    # Estimated lambda
    graphics::par(new=TRUE)
    graphics::plot(0, xlim=c(tStart, tEnd), ylim=c(0, max(seg$lambda)), col=0,
         xlab=NA, ylab=NA, main=NA, axes=FALSE)
    for(k in 1:nrow(seg)){
      graphics::lines(c(seg$begin[k], seg$end[k]), seg$lambda[k]*c(1, 1), col=col, lwd=2)
    }
    graphics::axis(side=4, col=2, col.ticks=2, col.axis=2)

    ##### Marks
    marks <- ProcessData$marks
    graphics::par(new=FALSE) # second graphe
    graphics::plot(0, xlim=c(tStart, tEnd), ylim=c(0, max(marks)), col=0, xlab=xlab, ylab=ylab, main=main)
    graphics::points(times, marks, pch=20,cex=0.8)
    # rho cum
    if (nrow(seg)!=1){
      graphics::abline(v=seg$end[1:(length(seg$end)-1)], col=2, lty=2)
    }
    for(k in 1:nrow(seg)){
      graphics::lines(c(seg$begin[k], seg$end[k]), (1/seg$rho[k])*c(1, 1), col=col, lwd=2)
    }
    graphics::axis(side=4, col=2, col.ticks=2, col.axis=2)
  }
}
